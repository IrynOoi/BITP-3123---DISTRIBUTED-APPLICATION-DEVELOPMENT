package view;

import com.github.sarxos.webcam.*;
import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.*;

public class Validation {
//for use case purpose
    private Webcam webcam;

    public Validation(JFrame parent) {
        JDialog dialog = new JDialog(parent, "QR Validator", true);
        dialog.setSize(700, 600);
        dialog.setLayout(new BorderLayout());

        JLabel statusLabel = new JLabel("Initializing QR validator...", SwingConstants.CENTER);
        dialog.add(statusLabel, BorderLayout.SOUTH);

        // Upload QR button
        JButton uploadButton = new JButton("Upload QR Image");
        uploadButton.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                String result = decodeQRCodeFromFile(file);
                if (result != null) {
                    statusLabel.setText("Valid QR code detected: " + result);
                    JOptionPane.showMessageDialog(dialog, "Valid QR: " + result);
                    dialog.dispose();
                } else {
                    statusLabel.setText("Invalid QR code or no QR found.");
                }
            }
        });

        JPanel topPanel = new JPanel();
        topPanel.add(uploadButton);
        dialog.add(topPanel, BorderLayout.NORTH);

        webcam = Webcam.getDefault();
        if (webcam != null) {
            webcam.setViewSize(new Dimension(640, 480));
            webcam.open();

            WebcamPanel webcamPanel = new WebcamPanel(webcam);
            webcamPanel.setFPSDisplayed(true);
            webcamPanel.setFillArea(true);
            dialog.add(webcamPanel, BorderLayout.CENTER);

            ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
            executor.scheduleAtFixedRate(() -> {
                BufferedImage image = webcam.getImage();
                if (image != null) {
                    Result result = decodeQR(image);
                    if (result != null) {
                        executor.shutdown();
                        SwingUtilities.invokeLater(() -> {
                            statusLabel.setText("Valid QR code detected: " + result.getText());
                            JOptionPane.showMessageDialog(dialog, "QR Detected: " + result.getText());
                            dialog.dispose();
                        });
                    }
                }
            }, 0, 100, TimeUnit.MILLISECONDS);

            dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {
                    executor.shutdownNow();
                    if (webcam != null) {
                        webcam.close();
                    }
                }
            });
        } else {
            statusLabel.setText("No webcam found. Upload only mode.");
        }

        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);
    }

    private Result decodeQR(BufferedImage image) {
        try {
            LuminanceSource source = new BufferedImageLuminanceSource(image);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            return new MultiFormatReader().decode(bitmap);
        } catch (NotFoundException e) {
            return null;
        }
    }

    private String decodeQRCodeFromFile(File file) {
        try {
            BufferedImage image = ImageIO.read(file);
            Result result = decodeQR(image);
            return result != null ? result.getText() : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Validation(null));
    }
}
