package view;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import model.AvailableEvent;
import model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class EventListViewer extends JFrame {

    private JTable eventTable;
    private DefaultTableModel tableModel;
    private List<AvailableEvent> eventList;
    private String idToken;

    public EventListViewer(String idToken) {    
        this.idToken = idToken;
        setTitle("Available Events");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        String[] columnNames = {"ID", "Title", "Start", "End", "Location", "Capacity", "Registration", "Detail"};
        tableModel = new DefaultTableModel(columnNames, 0);
        eventTable = new JTable(tableModel) {
            public boolean isCellEditable(int row, int column) {
                return column == 6 || column == 7;
            }
        };
        eventTable.setRowHeight(40);

        JScrollPane scrollPane = new JScrollPane(eventTable);
        add(scrollPane, BorderLayout.CENTER);

        eventTable.getColumn("Registration").setCellRenderer(new ButtonRenderer("Apply"));
        eventTable.getColumn("Registration").setCellEditor(new ButtonEditor(new JCheckBox(), "Apply"));

        eventTable.getColumn("Detail").setCellRenderer(new ButtonRenderer("View"));
        eventTable.getColumn("Detail").setCellEditor(new ButtonEditor(new JCheckBox(), "View"));

        loadEventsFromAPI();
    }

    private void loadEventsFromAPI() {
        try {
            URL url = new URL("http://localhost:8080/api/events/available");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            InputStream inputStream = conn.getInputStream();
            ObjectMapper mapper = new ObjectMapper();
            eventList = mapper.readValue(inputStream, new TypeReference<List<AvailableEvent>>() {});
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            for (AvailableEvent e : eventList) {
                String formattedStart = formatDateTime(e.getStartDateTime(), formatter);
                String formattedEnd = formatDateTime(e.getEndDateTime(), formatter);

                tableModel.addRow(new Object[]{
                        e.getEventId(),
                        e.getTitle(),
                        formattedStart,
                        formattedEnd,
                        e.getLocation(),
                        e.getCapacityDisplay(),
                        "Register",
                        "View"
                });
            }

            conn.disconnect();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading events: " + ex.getMessage());
        }
    }

    private String formatDateTime(String dateTimeStr, DateTimeFormatter formatter) {
        try {
            LocalDateTime dateTime = LocalDateTime.parse(dateTimeStr);
            return dateTime.format(formatter);
        } catch (Exception ex) {
            return dateTimeStr; // Fallback to raw if parsing fails
        }
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer(String label) {
            setOpaque(true);
            setText(label);
            if (label.equals("Apply")) {
                setBackground(Color.decode("#00ABE4"));
                setForeground(Color.WHITE);
            } else if (label.equals("View")) {
                setBackground(Color.decode("#FFA500"));
                setForeground(Color.WHITE);
            }
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private int selectedRow;

        public ButtonEditor(JCheckBox checkBox, String label) {
            super(checkBox);
            this.label = label;
            button = new JButton(label);
            button.setOpaque(true);

            if (label.equals("Apply")) {
                button.setBackground(Color.decode("#00ABE4"));
                button.setForeground(Color.WHITE);
            } else if (label.equals("View")) {
                button.setBackground(Color.decode("#FFA500"));
                button.setForeground(Color.WHITE);
            }

            button.addActionListener((ActionEvent e) -> {
                if (label.equals("Apply")) {
                    int eventId = (int) tableModel.getValueAt(selectedRow, 0);
                    sendRegisterRequest(eventId);
                } else if (label.equals("View")) {
                    showEventDetail(selectedRow);
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            selectedRow = row;
            return button;
        }

        public Object getCellEditorValue() {
            return label;
        }
    }

    private void showEventDetail(int row) {
        if (eventList != null && row < eventList.size()) {
            AvailableEvent event = eventList.get(row);
            JTextArea textArea = new JTextArea(event.getDescription());
            textArea.setWrapStyleWord(true);
            textArea.setLineWrap(true);
            textArea.setEditable(false);
            textArea.setBackground(null);
            textArea.setBorder(null);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 200));
            JOptionPane.showMessageDialog(this, scrollPane, "Event Description", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void sendRegisterRequest(int eventId) {
        try {
            URL url = new URL("http://localhost:8080/api/registration/"+ eventId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Bearer " + idToken);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write("".getBytes());
            }

            int responseCode = conn.getResponseCode();
            InputStream inputStream = (responseCode >= 200 && responseCode < 300)
                    ? conn.getInputStream() : conn.getErrorStream();

            StringBuilder response = new StringBuilder();
            try (inputStream;
                 java.util.Scanner scanner = new java.util.Scanner(inputStream)) {
                while (scanner.hasNextLine()) {
                    response.append(scanner.nextLine());
                }
            }

            if (responseCode == 200) {
                JOptionPane.showMessageDialog(this, response.toString());
            } else {
                JOptionPane.showMessageDialog(this, "Error " + responseCode + ": " + response.toString());
            }

            conn.disconnect();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error registering: " + ex.getMessage());
        }
    }
}
