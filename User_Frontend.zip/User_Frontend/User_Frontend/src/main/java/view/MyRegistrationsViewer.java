package view;

import model.User;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public class MyRegistrationsViewer extends JFrame {

    private String idToken;

    public MyRegistrationsViewer(String idToken) {
        this.idToken=idToken;
        setTitle("My Event Registrations");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columnNames = {"Event Title", "Registration Time", "Status", "Check-in Time"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadRegistrationData(model);
    }

    private void loadRegistrationData(DefaultTableModel model) {
        try {
            // Clear previous rows to prevent duplication
            model.setRowCount(0);

            String apiUrl = "http://localhost:8080/api/registration/registered";
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + idToken);
            conn.setRequestProperty("Accept", "application/json");

            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream())
                );
                StringBuilder responseBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    responseBuilder.append(line);
                }
                reader.close();
                conn.disconnect();

                // Print response for debugging
                String jsonResponse = responseBuilder.toString();
                System.out.println("API Response: " + jsonResponse);

                JSONArray jsonArray = new JSONArray(jsonResponse);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);

                    String eventTitle = obj.optString("eventTitle", "N/A");
                    String registrationTime = obj.optString("registrationTime", "N/A").replace("T", " ");
                    String status = obj.optString("status", "unknown");
                    String checkinTime = obj.isNull("checkinTime") 
                            ? "Not Checked In" 
                            : obj.getString("checkinTime").replace("T", " ");

                    model.addRow(new Object[]{eventTitle, registrationTime, status, checkinTime});
                }
            } else {
                BufferedReader errorReader = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream())
                );
                StringBuilder errorResponse = new StringBuilder();
                String errorLine;
                while ((errorLine = errorReader.readLine()) != null) {
                    errorResponse.append(errorLine);
                }
                errorReader.close();

                JOptionPane.showMessageDialog(this,
                        "Failed to load data.\nCode: " + responseCode +
                        "\nResponse: " + errorResponse.toString(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "An error occurred: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
