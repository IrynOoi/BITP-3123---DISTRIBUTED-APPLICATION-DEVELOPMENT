package view;

import model.User;
import javax.swing.*;
import java.awt.*;

public class StudentEventSystem {

    private final User user;
    private final String idToken;

    public StudentEventSystem(User user, String idToken) {
        this.user = user;
        this.idToken = idToken;
        initializeUI();
    }

    private void initializeUI() {
        JFrame frame = new JFrame("Student Event System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500); // Increased size for extra button
        frame.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Student Event System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        frame.add(titleLabel, BorderLayout.NORTH);

        JPanel menuPanel = new JPanel(new GridLayout(4, 1, 20, 20)); // 4 buttons now
        menuPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        JButton qrButton = new JButton("Event QR Scan");
        JButton eventListButton = new JButton("Event Registration List");
        JButton profileButton = new JButton("Student Profile");
        JButton myRegistrationsButton = new JButton("My Registrations & Check-ins"); // ✅ New button

        qrButton.addActionListener(e -> new QRScanDialog(frame, idToken));

        eventListButton.addActionListener(e -> {
            EventListViewer viewer = new EventListViewer(idToken);
            viewer.setVisible(true);
        });

        profileButton.addActionListener(e -> new StudentProfileDialog(frame, user));

        myRegistrationsButton.addActionListener(e -> {
            // Open your view for registration/check-in
            MyRegistrationsViewer viewer = new MyRegistrationsViewer(idToken); // replace with your actual class
            viewer.setVisible(true);
        });

        menuPanel.add(qrButton);
        menuPanel.add(eventListButton);
        menuPanel.add(profileButton);
        menuPanel.add(myRegistrationsButton); // ✅ Add to panel

        frame.add(menuPanel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
