package view;

import model.User;

import javax.swing.*;
import java.awt.*;

public class StudentProfileDialog {

    public StudentProfileDialog(JFrame parent, User user) {
    	//Save student infomation include registered event and maybe withdraw button
        JDialog dialog = new JDialog(parent, "Student Profile", true);
        dialog.setSize(400, 250);
        dialog.setLayout(new GridLayout(5, 2, 10, 10));

        dialog.add(new JLabel("Name:"));
        dialog.add(new JLabel(user.getName()));

        dialog.add(new JLabel("Matric Number:"));
        dialog.add(new JLabel("A123456")); // Placeholder

        dialog.add(new JLabel("Email:"));
        dialog.add(new JLabel(user.getEmail()));

        dialog.add(new JLabel("Role:"));
        dialog.add(new JLabel(user.getRole())); // Replace with real data if available

        JButton close = new JButton("Close");
        close.addActionListener(e -> dialog.dispose());
        dialog.add(new JLabel());
        dialog.add(close);

        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);
    }
}
