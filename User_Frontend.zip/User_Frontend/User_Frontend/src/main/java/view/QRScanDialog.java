package view;

import com.github.sarxos.webcam.*;
import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class QRScanDialog extends JDialog {

    private static final long serialVersionUID = 1L;

    private Webcam webcam;
    private WebcamPanel webcamPanel;
    private ScheduledExecutorService executor;
    private String scannedContent = null;
    private final String idToken;

    public QRScanDialog(JFrame parent, String idToken) {
        super(parent, "QR Scanner", true);
        this.idToken = idToken;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        initializeUI(parent);
    }

    private void initializeUI(JFrame parent) {
        setSize(700, 600);
        setLayout(new BorderLayout());

        JLabel statusLabel = new JLabel("Initializing...", SwingConstants.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        JButton uploadButton = new JButton("Upload QR Image");
        uploadButton.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                String result = decodeQRCodeFromFile(chooser.getSelectedFile());
                if (result != null) {
                    playBeep();
                    scannedContent = result;
                    String response = sendToServer(result, idToken);
                    statusLabel.setText(response);
                    JOptionPane.showMessageDialog(this, response);
                    closeResources();
                    dispose(); // close after upload scan
                } else {
                    statusLabel.setText("Invalid QR code.");
                }
            }
        });

        JPanel topPanel = new JPanel();
        topPanel.add(uploadButton);
        add(topPanel, BorderLayout.NORTH);

        webcam = Webcam.getDefault();
        if (webcam != null) {
            webcam.setViewSize(new Dimension(640, 480));
            webcam.open();

            webcamPanel = new WebcamPanel(webcam);
            webcamPanel.setFPSDisplayed(true);
            add(webcamPanel, BorderLayout.CENTER);

            executor = Executors.newSingleThreadScheduledExecutor();
            executor.scheduleAtFixedRate(() -> {
                if (!webcam.isOpen()) return;
                BufferedImage image = webcam.getImage();
                if (image != null) {
                    Result result = decodeQR(image);
                    if (result != null) {
                        scannedContent = result.getText();
                        String response = sendToServer(scannedContent, idToken);
                        SwingUtilities.invokeLater(() -> {
                            playBeep();
                            statusLabel.setText(response);
                            JOptionPane.showMessageDialog(this, response);
                            closeResources();
                            dispose();
                        });
                        executor.shutdownNow(); // stop further scanning
                    }
                }
            }, 0, 200, TimeUnit.MILLISECONDS);
        } else {
            statusLabel.setText("No webcam found - using file upload only");
        }

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                closeResources();
            }

            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                closeResources();
            }
        });

        setLocationRelativeTo(parent);
        setVisible(true);
    }

    private void closeResources() {
        try {
            if (executor != null && !executor.isShutdown()) {
                executor.shutdownNow();
            }
            if (webcam != null && webcam.isOpen()) {
                webcam.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private Result decodeQR(BufferedImage image) {
        try {
            LuminanceSource source = new BufferedImageLuminanceSource(image);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            return new MultiFormatReader().decode(bitmap);
        } catch (NotFoundException e) {
            return null;
        }
    }

    private String decodeQRCodeFromFile(File file) {
        try {
            BufferedImage image = ImageIO.read(file);
            Result result = decodeQR(image);
            return result != null ? result.getText() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String sendToServer(String qrToken, String idToken) {
        try {
            URL url = new URL("http://localhost:8080/api/checkin?qrToken=" + URLEncoder.encode(qrToken, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Bearer " + idToken);
            conn.setDoOutput(true);

            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    conn.getResponseCode() == 200 ? conn.getInputStream() : conn.getErrorStream()));
            StringBuilder sb = new StringBuilder();
            reader.lines().forEach(sb::append);
            return sb.toString();
        } catch (Exception e) {
            return "Server Error: " + e.getMessage();
        }
    }

    private void playBeep() {
        try {
            ToneGenerator.beep();
        } catch (Exception e) {
            System.err.println("Beep failed: " + e.getMessage());
        }
    }

    public String getResult() {
        return scannedContent;
    }

    static class ToneGenerator {
        public static void beep() throws LineUnavailableException {
            byte[] buf = new byte[1];
            AudioFormat af = new AudioFormat(8000f, 8, 1, true, false);
            try (SourceDataLine sdl = AudioSystem.getSourceDataLine(af)) {
                sdl.open(af);
                sdl.start();
                for (int i = 0; i < 200; i++) {
                    double angle = i / (8000f / 440) * 2.0 * Math.PI;
                    buf[0] = (byte) (Math.sin(angle) * 100);
                    sdl.write(buf, 0, 1);
                }
                sdl.drain();
            }
        }
    }
}
