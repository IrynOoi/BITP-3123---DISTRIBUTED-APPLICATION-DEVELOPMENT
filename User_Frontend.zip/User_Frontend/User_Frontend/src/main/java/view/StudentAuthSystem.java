package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.stream.Collectors;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import org.json.JSONObject;

import model.User;

public class StudentAuthSystem {

	private JFrame frame;
	private JTextField emailField;
	private JPasswordField passwordField;
	private final static String FIREBASE_API_KEY = "AIzaSyAJ92z6cda3voSrGYfC7LDpqR0nKtquU-w";
	private String idToken;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				StudentAuthSystem window = new StudentAuthSystem();
				window.frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public StudentAuthSystem() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame("Firebase Login");
		frame.setBounds(100, 100, 400, 250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(50, 30, 80, 25);
		frame.getContentPane().add(lblEmail);

		emailField = new JTextField();
		emailField.setBounds(150, 30, 180, 25);
		frame.getContentPane().add(emailField);
		emailField.setColumns(10);

		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(50, 70, 80, 25);
		frame.getContentPane().add(lblPassword);

		passwordField = new JPasswordField();
		passwordField.setBounds(150, 70, 180, 25);
		frame.getContentPane().add(passwordField);

		JButton loginBtn = new JButton("Login");
		loginBtn.setBounds(150, 120, 90, 30);
		frame.getContentPane().add(loginBtn);

		JButton registerBtn = new JButton("Register");
		registerBtn.setBounds(250, 120, 90, 30); // Adjust position if needed
		frame.getContentPane().add(registerBtn);

		registerBtn.addActionListener(e -> showRegisterDialog(frame));

		JLabel statusLabel = new JLabel("");
		statusLabel.setBounds(50, 160, 300, 25);
		frame.getContentPane().add(statusLabel);

		loginBtn.addActionListener(e -> {
			String email = emailField.getText();
			String password = new String(passwordField.getPassword());

			try {
				boolean success = loginWithFirebase(email, password);
				if (success) {
					statusLabel.setText("Login successful!");
					statusLabel.setForeground(Color.GREEN);
					User user = getUserByGmailFromBackend();
					if (user == null) {
						statusLabel.setText("Login failed.");
						statusLabel.setForeground(Color.RED);
					} else {
						EventQueue.invokeLater(() -> {
							if (user.getRole().equalsIgnoreCase("student")) {
								new StudentEventSystem(user, idToken);
							}

							frame.dispose(); // close login window
						});
					}

				} else {
					statusLabel.setText("Login failed.");
					statusLabel.setForeground(Color.RED);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				statusLabel.setText("Error occurred.");
				statusLabel.setForeground(Color.RED);
			}
		});
	}

	private boolean loginWithFirebase(String email, String password) throws IOException {
		String urlStr = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + FIREBASE_API_KEY;
		URL url = new URL(urlStr);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();

		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setDoOutput(true);

		JSONObject requestBody = new JSONObject();
		requestBody.put("email", email);
		requestBody.put("password", password);
		requestBody.put("returnSecureToken", true);

		OutputStream os = conn.getOutputStream();
		os.write(requestBody.toString().getBytes());
		os.flush();
		os.close();

		int responseCode = conn.getResponseCode();
		InputStream is = (responseCode == 200) ? conn.getInputStream() : conn.getErrorStream();

		BufferedReader in = new BufferedReader(new InputStreamReader(is));
		String inputLine;
		StringBuilder response = new StringBuilder();
		while ((inputLine = in.readLine()) != null)
			response.append(inputLine);
		in.close();

		if (responseCode == 200) {
			JSONObject jsonResponse = new JSONObject(response.toString());
			System.out.println("Login Successful, ID Token: " + jsonResponse.getString("idToken"));
			idToken = jsonResponse.getString("idToken");
			return true;
		} else {
			JSONObject error = new JSONObject(response.toString());
			String errorMessage = error.optJSONObject("error").optString("message", "Unknown error");
			System.out.println("Login Failed: " + errorMessage);
			return false;
		}
	}

	private User getUserByGmailFromBackend() throws IOException {
		String apiUrl = "http://localhost:8080/api/user/email"; // Adjust to your backend URL
		URL url = new URL(apiUrl);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setDoOutput(true);

		// Send email as JSON in request body
		JSONObject body = new JSONObject();
		body.put("email", emailField.getText());

		OutputStream os = conn.getOutputStream();
		os.write(body.toString().getBytes());
		os.flush();
		os.close();

		int responseCode = conn.getResponseCode();
		if (responseCode == 200)
		{
			InputStream is = conn.getInputStream();

			BufferedReader in = new BufferedReader(new InputStreamReader(is));
			StringBuilder response = new StringBuilder();
			String line;
			while ((line = in.readLine()) != null) {
				response.append(line);
			}
			in.close();
			JSONObject json = new JSONObject(response.toString());
			User user = new User();
			
			 user.setUserId(json.getString("userId"));
			 user.setEmail(json.getString("email")); 
			 user.setName(json.getString("name"));
			 user.setRole(json.getString("role"));
			 user.setCreatedAt(java.time.LocalDateTime.parse(json.getString("createdAt"))); 
			 return user;
		}
		else{
			System.out.println("Failed to get user info");
			return null;
		}
	}

	private static void showRegisterDialog(JFrame parent) {
		JDialog registerDialog = new JDialog(parent, "Student Registration", true);
		registerDialog.setLayout(new GridLayout(7, 2, 10, 10)); // One extra row for name

		JLabel nameLabel = new JLabel("Name:");
		JTextField nameField = new JTextField();
		JLabel emailLabel = new JLabel("Email:");
		JTextField emailField = new JTextField();
		JLabel matricLabel = new JLabel("Matric Number:");
		JTextField matricField = new JTextField();
		JLabel passwordLabel = new JLabel("Password:");
		JPasswordField passwordField = new JPasswordField();
		JLabel confirmLabel = new JLabel("Confirm Password:");
		JPasswordField confirmField = new JPasswordField();
		JButton submitButton = new JButton("Register");

		submitButton.addActionListener(e -> {
			String name = nameField.getText();
			String email = emailField.getText();
			String matric = matricField.getText();
			String password = new String(passwordField.getPassword());
			String confirm = new String(confirmField.getPassword());

			if (name.isEmpty() || email.isEmpty() || matric.isEmpty() || password.isEmpty()) {
				JOptionPane.showMessageDialog(registerDialog, "All fields are required!", "Error",
						JOptionPane.ERROR_MESSAGE);
			} else if (!password.equals(confirm)) {
				JOptionPane.showMessageDialog(registerDialog, "Passwords do not match!", "Error",
						JOptionPane.ERROR_MESSAGE);
			} else {
				try {
					// ✅ Firebase REST API - Sign Up
					String urlStr = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + FIREBASE_API_KEY;
					URL url = new URL(urlStr);
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setRequestMethod("POST");
					conn.setRequestProperty("Content-Type", "application/json");
					conn.setDoOutput(true);

					JSONObject firebaseRequest = new JSONObject();
					firebaseRequest.put("email", email);
					firebaseRequest.put("password", password);
					firebaseRequest.put("returnSecureToken", true);

					OutputStream os = conn.getOutputStream();
					os.write(firebaseRequest.toString().getBytes());
					os.flush();
					os.close();

					int responseCode = conn.getResponseCode();
					InputStream is = (responseCode == 200) ? conn.getInputStream() : conn.getErrorStream();
					BufferedReader in = new BufferedReader(new InputStreamReader(is));
					String response = in.lines().collect(Collectors.joining("\n"));
					in.close();

					if (responseCode != 200) {
						JSONObject error = new JSONObject(response);
						String message = error.optJSONObject("error").optString("message", "Unknown error");
						JOptionPane.showMessageDialog(registerDialog, "Firebase registration failed: " + message,
								"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}

					JSONObject result = new JSONObject(response);
					String uid = result.getString("localId"); // Firebase UID

					// ✅ Backend registration
					JSONObject json = new JSONObject();
					json.put("userId", matric); // or UID if you prefer
					json.put("name", name);
					json.put("role", "student");
					json.put("email", email);

					try {
						URL backendUrl = new URL("http://localhost:8080/api/user/register");
						HttpURLConnection backendConn = (HttpURLConnection) backendUrl.openConnection();
						backendConn.setRequestMethod("POST");
						backendConn.setRequestProperty("Content-Type", "application/json");
						backendConn.setDoOutput(true);

						OutputStream os2 = backendConn.getOutputStream();
						os2.write(json.toString().getBytes("utf-8"));
						os2.flush();
						os2.close();

						int code = backendConn.getResponseCode();
						if (code == HttpURLConnection.HTTP_OK) {
							JOptionPane.showMessageDialog(registerDialog, "Registration successful!", "Success",
									JOptionPane.INFORMATION_MESSAGE);
							registerDialog.dispose();
						} else {
							InputStream errorStream = backendConn.getErrorStream();
							String errorMsg = new BufferedReader(new InputStreamReader(errorStream)).lines()
									.collect(Collectors.joining("\n"));
							JOptionPane.showMessageDialog(registerDialog, "Backend error: " + errorMsg, "Error",
									JOptionPane.ERROR_MESSAGE);
						}
					} catch (IOException ex) {
						JOptionPane.showMessageDialog(registerDialog, "Backend connection error: " + ex.getMessage(),
								"Error", JOptionPane.ERROR_MESSAGE);
					}

				} catch (Exception ex) {
					JOptionPane.showMessageDialog(registerDialog, "Unexpected error: " + ex.getMessage(), "Error",
							JOptionPane.ERROR_MESSAGE);
					ex.printStackTrace();
				}
			}
		});

		registerDialog.add(nameLabel);
		registerDialog.add(nameField);
		registerDialog.add(emailLabel);
		registerDialog.add(emailField);
		registerDialog.add(matricLabel);
		registerDialog.add(matricField);
		registerDialog.add(passwordLabel);
		registerDialog.add(passwordField);
		registerDialog.add(confirmLabel);
		registerDialog.add(confirmField);
		registerDialog.add(new JLabel()); // Empty cell
		registerDialog.add(new JLabel()); // Empty cell
		registerDialog.add(new JLabel()); // Empty cell
		registerDialog.add(submitButton);

		registerDialog.pack();
		registerDialog.setLocationRelativeTo(parent);
		registerDialog.setVisible(true);
	}

}
