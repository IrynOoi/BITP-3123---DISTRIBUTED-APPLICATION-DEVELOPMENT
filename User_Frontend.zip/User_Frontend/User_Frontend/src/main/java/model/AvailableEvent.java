package model;

public class AvailableEvent {
    private int eventId;
    private String title;
    private String description;
    private String startDateTime;
    private String endDateTime;
    private String location;
    private int approvedRegistrations;
    private int capacity;
    private String capacityDisplay;

    // Constructors
    public AvailableEvent() {}

    public AvailableEvent(int eventId, String title, String description, String startDateTime,
                          String endDateTime, String location, int approvedRegistrations,
                          int capacity, String capacityDisplay) {
        this.eventId = eventId;
        this.title = title;
        this.description = description;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.location = location;
        this.approvedRegistrations = approvedRegistrations;
        this.capacity = capacity;
        this.capacityDisplay = capacityDisplay;
    }

    // Getters and Setters
    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(String startDateTime) {
        this.startDateTime = startDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getApprovedRegistrations() {
        return approvedRegistrations;
    }

    public void setApprovedRegistrations(int approvedRegistrations) {
        this.approvedRegistrations = approvedRegistrations;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getCapacityDisplay() {
        return capacityDisplay;
    }

    public void setCapacityDisplay(String capacityDisplay) {
        this.capacityDisplay = capacityDisplay;
    }
}

