package com.eventgo.backend_api.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.eventgo.backend_api.model.AttendanceStats;
import com.eventgo.backend_api.repository.AttendanceStatsRepository;

@Service
public class AttendanceStatsService {

    private final AttendanceStatsRepository attendanceStatsRepository;

    public AttendanceStatsService(AttendanceStatsRepository attendanceStatsRepository) {
        this.attendanceStatsRepository = attendanceStatsRepository;
    }

    public List<AttendanceStats> getAllAttendanceStats() {
        return attendanceStatsRepository.findAll();
    }

    // ✅ Add this method to resolve controller error
    public AttendanceStats getStatsByEventId(Integer eventId) 
    {
        return attendanceStatsRepository.findByEventId(eventId);
    }
}
