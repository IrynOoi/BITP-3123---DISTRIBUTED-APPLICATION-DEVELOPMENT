package com.eventgo.backend_api.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.eventgo.backend_api.model.AvailableEvent;
import com.eventgo.backend_api.model.Event;
import com.eventgo.backend_api.model.PublishEventRequest;
import com.eventgo.backend_api.repository.AvailableEventRepository;
import com.eventgo.backend_api.repository.EventRepository;

@Service
public class EventService {
	
	 private final EventRepository eventRepository;
	 private final AvailableEventRepository AERepository;
	 
	 // Constructor injection - make sure the constructor name matches the class name
	 public EventService(EventRepository eventRepository,AvailableEventRepository AERepository) {
	     this.eventRepository = eventRepository;
	     this.AERepository = AERepository;
	 }
	 
	 public List<Event> getAllEvent()
	 {
		List <Event> events = eventRepository.findAll();
		return events;
	 }
	 
	 public String getQR_Token(Integer eventId)
	 {
		 return eventRepository.findById(eventId)
	                .map(Event::getQrToken)
	                .orElseThrow(() -> new RuntimeException("Event not found with id: " + eventId));
		 
	 }
	 
	 public Event createEvent(PublishEventRequest request) {
         Event event = new Event();

         event.setTitle(request.getTitle());
         event.setDescription(request.getDescription());
         event.setStartDateTime(request.getStartDateTime());
         event.setEndDateTime(request.getEndDateTime());
         event.setLocation(request.getLocation());
         event.setCapacity(request.getCapacity());
         event.setUserId(request.getUserId());
         String qrToken = UUID.randomUUID().toString();
         event.setQrToken(qrToken);
         event.setCreatedAt(LocalDateTime.now());

         return eventRepository.save(event);
     }
	 
	 public List<AvailableEvent> getAvailableEvents() {
	        return AERepository.findAll();
	    }
	 
	 public boolean isEventExist(Integer eventId) {
	        Optional<Event > event = eventRepository.findById(eventId);
	        if(event.isPresent())
	        	
	        	return true;
	        else
	        {	
	        	return false;
	        
	        }
	    }

}
