package com.eventgo.backend_api.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.eventgo.backend_api.service.AttendanceStatsService;
import com.eventgo.backend_api.service.EventService;
import com.eventgo.backend_api.service.QRService;
import com.google.zxing.WriterException;
import com.eventgo.backend_api.model.AttendanceStats;
import com.eventgo.backend_api.model.AvailableEvent;
import com.eventgo.backend_api.model.Event;
import com.eventgo.backend_api.model.PublishEventRequest;


@RestController
@RequestMapping("/api/events")
public class EventController {

	
	private final EventService eventService;
	private final QRService qrService;
	private final AttendanceStatsService statsService;
	
	public EventController(EventService eventService,QRService qrService,AttendanceStatsService statsService){
			
		this.eventService = eventService;
		this.qrService = qrService;
        this.statsService = statsService;
	}
	
	@GetMapping
	public List<Event> getAllEvent()
	{
		List<Event> events = eventService.getAllEvent();
		return events;
	}
	
	@GetMapping("/QRCode")
	public ResponseEntity<?> getEventQRCodeImage(@RequestParam Integer eventId) {
	    try {
	        // ✅ Check if the event exists
	        if (!eventService.isEventExist(eventId)) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                    .contentType(MediaType.TEXT_PLAIN)
	                    .body(("Event not found for ID: " + eventId).getBytes());
	        }

	        // ✅ Check QR Token
	        String qrToken = eventService.getQR_Token(eventId);
	        if (qrToken == null || qrToken.isBlank()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                    .contentType(MediaType.TEXT_PLAIN)
	                    .body(("QR Token not found for event ID: " + eventId).getBytes());
	        }

	        // ✅ Generate QR Code
	        BufferedImage image = qrService.generateQRCodeImage(qrToken);
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        ImageIO.write(image, "png", baos);
	        byte[] imageBytes = baos.toByteArray();

	        // ✅ Return image
	        return ResponseEntity.ok()
	                .contentType(MediaType.IMAGE_PNG)
	                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"event-" + eventId + ".png\"")
	                .header(HttpHeaders.CACHE_CONTROL, "no-cache, no-store, must-revalidate")
	                .header(HttpHeaders.PRAGMA, "no-cache")
	                .header(HttpHeaders.EXPIRES, "0")
	                .body(imageBytes);

	    } catch (IOException | WriterException e) {
	        String errorMessage = "QR code generation failed: " + e.getMessage();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .contentType(MediaType.TEXT_PLAIN)
	                .body(errorMessage.getBytes());
	    }
	}
	
	 @GetMapping("/attendanceStats")
	    public AttendanceStats getStats(@RequestParam String event_id) {
	        Integer eventId = Integer.valueOf(event_id);  // convert String to Integer
	        return statsService.getStatsByEventId(eventId);
	    }	
	 
	 @PostMapping("/publish")
	    public ResponseEntity<String> publishActivity(@RequestBody PublishEventRequest request) {
	        try {
	            eventService.createEvent(request);
	            return ResponseEntity.ok("Activity published successfully");
	        } catch (Exception e) {
	            return ResponseEntity.status(500).body("Failed to publish activity: " + e.getMessage());
	        }
	    } 
	 
	 @GetMapping("/available")
	    public List<AvailableEvent> getAvailableEvents() {
	        return eventService.getAvailableEvents();
	    }
}
