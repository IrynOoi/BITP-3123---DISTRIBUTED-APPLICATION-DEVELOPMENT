package com.eventgo.backend_api.repository;

import com.eventgo.backend_api.model.CheckIn;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CheckInRepository extends JpaRepository<CheckIn, Integer> {
	
	  CheckIn findByRegistrationId(Integer registrationId);
	  List<CheckIn> findByRegistrationIdIn(List<Integer> registrationIds);
}
