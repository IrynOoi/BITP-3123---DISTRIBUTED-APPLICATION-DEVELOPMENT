package com.eventgo.backend_api.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="checkin")
public class CheckIn {
	 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "checkin_id")
	    private Integer checkinId;

	    @Column(name = "registration_id", nullable = false, unique = true)
	    private Integer registrationId;

	    @Column(name = "checkin_time", nullable = false)
	    private LocalDateTime checkinTime;

	    public CheckIn() {
			// TODO Auto-generated constructor stub
		}

	    // Getters and Setters
	    public Integer getCheckinId() 
	    {
	        return checkinId;
	    }

	    public void setCheckinId(Integer checkinId) {
	        this.checkinId = checkinId;
	    }

	    public Integer getRegistrationId() {
	        return registrationId;
	    }

	    public void setRegistrationId(Integer registrationId) {
	        this.registrationId = registrationId;
	    }

	    public LocalDateTime getCheckinTime() {
	        return checkinTime;
	    }

	    public void setCheckinTime(LocalDateTime checkinTime) {
	        this.checkinTime = checkinTime;
	    }
}
