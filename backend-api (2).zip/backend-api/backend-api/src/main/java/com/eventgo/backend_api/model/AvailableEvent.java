package com.eventgo.backend_api.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "view_available_events")  // Name of your SQL view
public class AvailableEvent {

    @Id
    @Column(name = "event_id")  // assuming event_id is unique and exists in the view
    private Integer eventId;

    private String title;
    private String description;

    @Column(name = "start_date_time")
    private LocalDateTime startDateTime;

    @Column(name = "end_date_time")
    private LocalDateTime endDateTime;

    private String location;

    @Column(name = "approved_registrations")
    private Long approvedRegistrations;

    private Integer capacity;

    public AvailableEvent() {
        // JPA requires a default constructor
    }

    public AvailableEvent(Integer eventId, String title, String description,
                          LocalDateTime startDateTime, LocalDateTime endDateTime,
                          String location, Long approvedRegistrations, Integer capacity) {
        this.eventId = eventId;
        this.title = title;
        this.description = description;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.location = location;
        this.approvedRegistrations = approvedRegistrations;
        this.capacity = capacity;
    }

    // Getters
    public Integer getEventId() { return eventId; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public LocalDateTime getStartDateTime() { return startDateTime; }
    public LocalDateTime getEndDateTime() { return endDateTime; }
    public String getLocation() { return location; }
    public Long getApprovedRegistrations() { return approvedRegistrations; }
    public Integer getCapacity() { return capacity; }

    // Optional: For UI display
    public String getCapacityDisplay() {
        return approvedRegistrations + "/" + capacity;
    }
}
