package com.eventgo.backend_api.repository;

import com.eventgo.backend_api.model.AttendanceStats;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttendanceStatsRepository extends JpaRepository<AttendanceStats, Integer>{
	AttendanceStats findByEventId(Integer eventId);
}
