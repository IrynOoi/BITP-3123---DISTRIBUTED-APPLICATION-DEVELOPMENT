package com.eventgo.backend_api.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.eventgo.backend_api.model.RegisteredEvent;
import com.eventgo.backend_api.model.Registration;
import com.eventgo.backend_api.model.User;
import com.eventgo.backend_api.repository.RegisteredEventRepository;
import com.eventgo.backend_api.repository.RegistrationRepository;
import com.eventgo.backend_api.repository.UserRepository;

@Service
public class RegistrationService {
	
	 private final RegistrationRepository regeRepository;
	 private final UserRepository userRepository; 
	 private final RegisteredEventRepository RERepository;
	 // Constructor injection - make sure the constructor name matches the class name
	 public RegistrationService(RegistrationRepository regeRepository, UserRepository userRepository,RegisteredEventRepository RERepository) {
	     this.regeRepository = regeRepository;
	     this.userRepository = userRepository;
	     this.RERepository = RERepository;
	 }

	 public Registration registerEvent(String userID,Integer eventID)
	 {
		 Registration rege = new Registration();
		 rege.setEventId(eventID);
		 rege.setUserId(userID);
		 rege.setRegistrationTime(LocalDateTime.now());	 
		return regeRepository.save(rege);
	 }
	 
	 public List<Map<String, String>> getRegistrationsByEventId(Integer eventId) {
		    List<Registration> registrations = regeRepository.findAll().stream()
		            .filter(r -> r.getEventId().equals(eventId))
		            .collect(Collectors.toList());

		    List<Map<String, String>> response = new ArrayList<>();

		    for (Registration r : registrations) {
		        String userId = r.getUserId();
		        Optional<User> userOpt = userRepository.findById(userId);

		        if (userOpt.isPresent()) {
		            User user = userOpt.get();
		            Map<String, String> entry = new HashMap<>();
		            entry.put("student_id", userId);
		            entry.put("name", user.getName());
		            entry.put("status", r.getStatus());
		            response.add(entry);
		        }
		    }

		    return response;
		}

	 
	 public ResponseEntity<String> updateRegistrationStatus(Map<String, String> payload) {
		    try {
		        String eventIdStr = payload.get("event_id");
		        String studentIdStr = payload.get("student_id");
		        String status = payload.get("status");

		        if (eventIdStr == null || studentIdStr == null || status == null) {
		            return ResponseEntity.badRequest().body("Missing required fields.");
		        }

		        Integer eventId = Integer.parseInt(eventIdStr);
		        String studentId = studentIdStr;

		        // Lookup Registration by eventId and studentId
		        Optional<Registration> registrationOpt = regeRepository.findByEventIdAndUserId(eventId, studentId);

		        if (registrationOpt.isEmpty()) {
		            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Registration not found.");
		        }

		        Registration registration = registrationOpt.get();
		        registration.setStatus(status);
		        regeRepository.save(registration);

		        return ResponseEntity.ok("Status updated successfully.");
		    } catch (Exception e) {
		        e.printStackTrace();
		        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating status.");
		    }
		}
	 
	 public List<RegisteredEvent> getRegisteredEventsByUserId(String userId) {
	        
		 List<RegisteredEvent> events =RERepository.findByUserId(userId);
		 for(RegisteredEvent event:events)
         {
        	 System.out.println(event.getEventTitle());
         }
		 return events;
	    }
	 
	 
	 public boolean checkIfAleardyRegistered(Integer eventId,String userId)
	 {
		 Optional <Registration> rege = regeRepository.findByEventIdAndUserId(eventId, userId);
		 if (rege.isPresent())
			 return true;
		 else
			 return false;
	 }
}
