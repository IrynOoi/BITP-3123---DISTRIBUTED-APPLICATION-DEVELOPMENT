package com.eventgo.backend_api.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

public class PublishEventRequest {

	    private String title;
	    private String description;

	    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	    private LocalDateTime startDateTime;

	    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	    private LocalDateTime endDateTime;


	    private String location;
	    private int capacity;
		private String userId;
	    private String qrToken;

	    // Getters and Setters
	    
	    public String getTitle() {
	        return title;
	    }

	    public void setTitle(String title) {
	        this.title = title;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public LocalDateTime getStartDateTime() {
	        return startDateTime;
	    }

	    public void setStartDateTime(LocalDateTime startDateTime) {
	        this.startDateTime = startDateTime;
	    }

	    public LocalDateTime getEndDateTime() {
	        return endDateTime;
	    }

	    public void setEndDateTime(LocalDateTime endDateTime) {
	        this.endDateTime = endDateTime;
	    }

	    public String getLocation() {
	        return location;
	    }

	    public void setLocation(String location) {
	        this.location = location;
	    }

	    public int getCapacity() {
	        return capacity;
	    }

	    public void setCapacity(int capacity) {
	        this.capacity = capacity;
	    }

	    public String getUserId() {
	        return userId;
	    }

	    public void setUserId(String userId) {
	        this.userId = userId;
	    }
	    
	    public String getQrToken() {
			return qrToken;
		}

		public void setQrToken(String qrToken) {
			this.qrToken = qrToken;
		}
}
