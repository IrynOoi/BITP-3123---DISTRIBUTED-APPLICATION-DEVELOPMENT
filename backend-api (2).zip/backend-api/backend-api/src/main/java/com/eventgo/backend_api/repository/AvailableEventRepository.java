package com.eventgo.backend_api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eventgo.backend_api.model.AvailableEvent;

public interface AvailableEventRepository extends JpaRepository<AvailableEvent, Integer> {
   
}