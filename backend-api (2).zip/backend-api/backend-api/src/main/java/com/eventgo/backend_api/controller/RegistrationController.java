package com.eventgo.backend_api.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eventgo.backend_api.model.RegisteredEvent;
import com.eventgo.backend_api.model.Registration;
import com.eventgo.backend_api.model.User;
import com.eventgo.backend_api.service.RegistrationService;
import com.eventgo.backend_api.service.UserService;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;

import jakarta.servlet.http.HttpServletRequest;


@RestController
@RequestMapping("/api/registration")
public class RegistrationController {

	
	private final RegistrationService regeService;
	private final UserService userService;
	
	public RegistrationController(RegistrationService regeService,UserService userService) {
		this.regeService = regeService;
		this.userService =userService;
	}
	
	
	@PostMapping("/{eventId}")
	public ResponseEntity<String> registerEvent(@PathVariable Integer eventId,HttpServletRequest request) {
	    try {
	    	
		    String authHeader = request.getHeader("Authorization");

		    if (authHeader == null || !authHeader.startsWith("Bearer ")) {
		        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
		                                 .body(null);
		    }

		    String idToken = authHeader.substring(7); // Remove "Bearer "
		    FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(idToken);
		    String email = decodedToken.getEmail();
		        
	        User user = userService.getUserByEmail(email);
	        if (user == null) {
	            return ResponseEntity.status(404).body("User not found for provided email.");
	        }
	    	
	    	String userId = user.getUserId();
	        // Check if user already registered for the event
	        boolean isRegistered = regeService.checkIfAleardyRegistered(eventId, userId);
	        
	        if (isRegistered) {
	            return ResponseEntity
	                    .status(HttpStatus.CONFLICT)
	                    .body("User " + userId + " already registered for event " + eventId);
	        }

	        // Register the user
	        Registration rege = regeService.registerEvent(userId, eventId);

	        return ResponseEntity
	                .ok("Registered user " + userId + " to event " + eventId);

	    } catch (Exception e) {
	        return ResponseEntity
	                .status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Error registering user: " + e.getMessage());
	    }
	}
	
	 @PostMapping("/update-status")
	    public ResponseEntity<String> updateRegistrationStatus(
	            @RequestBody Map<String, String> payload) {
	        return regeService.updateRegistrationStatus(payload);
	   }
	
	 @GetMapping("/registered")
	 public ResponseEntity<List<RegisteredEvent>> getByUserId(HttpServletRequest request) {
	     try {
	         // ✅ 1. Validate Authorization header
	         String authHeader = request.getHeader("Authorization");
	         if (authHeader == null || !authHeader.startsWith("Bearer ")) {
	             return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
	                     .body(null);
	         }

	         // ✅ 2. Verify Firebase ID token
	         String idToken = authHeader.substring(7); // Remove "Bearer "
	         FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(idToken);
	         String email = decodedToken.getEmail();

	         // ✅ 3. Get user by email
	         User user = userService.getUserByEmail(email);
	         if (user == null) {
	             return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // 🛠️ fix missing .body()
	         }

	         // ✅ 4. Get registered events
	         String userId = user.getUserId();
	         List<RegisteredEvent> events = regeService.getRegisteredEventsByUserId(userId);
	         
	         for(RegisteredEvent event:events)
	         {
	        	 System.out.println(event.getEventTitle());
	         }
	         return ResponseEntity.ok(events);

	     } catch (Exception e) {
	         e.printStackTrace();
	         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                 .body(null);
	     }
	 }

	 @GetMapping("/byEvent")
	 public ResponseEntity<List<Map<String, String>>> getRegistrationsByEventId(@RequestParam Integer eventId) {
	     List<Map<String, String>> registrations = regeService.getRegistrationsByEventId(eventId);
	     return ResponseEntity.ok(registrations);
	 }

	 
}
