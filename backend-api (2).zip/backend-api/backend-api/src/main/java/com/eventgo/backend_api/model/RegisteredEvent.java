package com.eventgo.backend_api.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "view_registered_events")  // This must match your SQL view name
public class RegisteredEvent {

	@Id
    @Column(name = "registration_id", nullable = false, updatable = false)
    private Integer registrationId;
	
    @Column(name = "user_id") // or manually define if view includes no PK
    private String userId;

    @Column(name = "event_title")
    private String eventTitle;

    @Column(name = "registration_time")
    private LocalDateTime registrationTime;

    @Column(name = "registration_status")
    private String status;

    @Column(name = "checkin_time")
    private LocalDateTime checkinTime;

    public RegisteredEvent() {
        // JPA needs this
    }

    public RegisteredEvent(String eventTitle, LocalDateTime registrationTime, String status, LocalDateTime checkinTime) {
        this.eventTitle = eventTitle;
        this.registrationTime = registrationTime;
        this.status = status;
        this.checkinTime = checkinTime;
    }

    // Getters
    public String getEventTitle() { return eventTitle; }
    public LocalDateTime getRegistrationTime() { return registrationTime; }
    public String getStatus() { return status; }
    public LocalDateTime getCheckinTime() { return checkinTime; }
}
