package com.eventgo.backend_api.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eventgo.backend_api.model.CreateUserRequest;
import com.eventgo.backend_api.model.User;
import com.eventgo.backend_api.service.UserService;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/user")
public class UserController {

	private final UserService userService;

	public UserController(UserService userService ) {
		this.userService= userService;// TODO Auto-generated constructor stub
	}

	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@RequestBody CreateUserRequest request) {
		try
		{
			userService.registerUser(request);
			return ResponseEntity.ok("User registered successfully");
		}catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to register account: " + e.getMessage());
        }	
	}

	@PostMapping("/email")
	public ResponseEntity<User> getUserByEmail(@RequestBody Map<String, String> payload) {
	    String email = payload.get("email");
	    User user = userService.getUserByEmail(email); // your service method
	    if (user != null) {
	    	System.out.print(user.getCreatedAt()+user.getRole()+user.getEmail()+user.getUserId()+user.getName());
	        return ResponseEntity.ok(user);
	    } else {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	    }
	}


}
