package com.eventgo.backend_api.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eventgo.backend_api.model.CheckIn;
import com.eventgo.backend_api.model.Event;
import com.eventgo.backend_api.model.Registration;
import com.eventgo.backend_api.model.User;
import com.eventgo.backend_api.repository.CheckInRepository;
import com.eventgo.backend_api.repository.EventRepository;
import com.eventgo.backend_api.repository.RegistrationRepository;
import com.eventgo.backend_api.repository.UserRepository;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import com.google.firebase.cloud.FirestoreClient;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/checkin")
public class CheckInController {

	private final EventRepository evenRepo;
	private final UserRepository userRepo;
	private final RegistrationRepository registerRepo;
	private final CheckInRepository checkInRepo;
	
	public CheckInController(EventRepository evenRepo, UserRepository userRepo,RegistrationRepository registerRepo,CheckInRepository checkInRepo) {
		this.evenRepo = evenRepo;
		this.userRepo = userRepo;
		this.registerRepo=registerRepo;
		this.checkInRepo = checkInRepo;
	}
	
	@PostMapping()
	public ResponseEntity<String> checkin(@RequestParam String qrToken, HttpServletRequest request) {
		 try {
		        String authHeader = request.getHeader("Authorization");

		        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
		            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
		                                 .body(null);
		        }

		    String idToken = authHeader.substring(7); // Remove "Bearer "
		    FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(idToken);
		    String email = decodedToken.getEmail();
		        
	        Optional <User> optUser = userRepo.findByEmail(email);
	        if (optUser.isEmpty()) {
	            return ResponseEntity.status(404).body("User not found for provided email.");
	        }

	        // 3. Find event by QR token
	        Event event = evenRepo.findByQrToken(qrToken);
	        if (event == null) {
	            return ResponseEntity.status(404).body("Event not found for provided QR token.");
	        }

	        // 4. Get registration
	        Integer eventID = event.getEventId();
	        User user = optUser.get();
	        String userID = user.getUserId();
	        Optional<Registration> registration = registerRepo.findByEventIdAndUserId(eventID, userID);
	        
	        if (registration.isEmpty()) {
	            return ResponseEntity.status(404).body("No registration found.");
	        }

	        Registration reg = registration.get();
	        if (reg.getStatus().equalsIgnoreCase("pending") || reg.getStatus().equalsIgnoreCase("rejected")) {
	            return ResponseEntity.status(403).body("Registration is not approved.");
	        }

	        // 5. Check if already checked in
	        Integer registrationID = reg.getRegistrationId();
	        CheckIn existingCheckIn = checkInRepo.findByRegistrationId(registrationID);
	        if (existingCheckIn != null) {
	            return ResponseEntity.status(403).body("You have already checked in.");
	        }

	        // 6. Create new check-in
	        CheckIn newCheckIn = new CheckIn();
	        newCheckIn.setRegistrationId(registrationID);
	        newCheckIn.setCheckinTime(LocalDateTime.now());
	        checkInRepo.save(newCheckIn);
	        
	     // 7. Save to Firebase Firestore
            Firestore db = FirestoreClient.getFirestore();

            Map<String, Object> checkInData = new HashMap<>();
            checkInData.put("registrationId", registrationID);
            checkInData.put("userId", userID);
            checkInData.put("eventId", eventID);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            String formattedCheckinTime = newCheckIn.getCheckinTime().format(formatter);
            checkInData.put("checkinTime", formattedCheckinTime);

            checkInData.put("email", user.getEmail());
            checkInData.put("name", user.getName());

            ApiFuture<DocumentReference> result = db.collection("checkins").add(checkInData);
            
            try {
                DocumentReference docRef = result.get();
                System.out.println("Firestore document written with ID: " + docRef.getId());
            } catch (InterruptedException | ExecutionException e) {
                System.err.println("Firestore write failed: " + e.getMessage());
                // Consider adding retry logic here
            }
            
	        return ResponseEntity.ok("✅ Check-in successful");

	    } catch (Exception e) {
	        e.printStackTrace();
	        return ResponseEntity.status(500).body("❌ Server error: " + e.getMessage());
	    }
	}
	
	@GetMapping("/signIn")
    public ResponseEntity<List<Map<String, String>>> getCheckinsByEvent(@RequestParam("event_id") Integer eventId) {
        List<Registration> registrations = registerRepo.findByEventId(eventId);
        for(Registration rege: registrations)
        {	
        	System.out.println(rege.getRegistrationId());
        }
        Map<Integer, Registration> regMap = registrations.stream()
            .collect(Collectors.toMap(Registration::getRegistrationId, r -> r));

        List<CheckIn> checkins = checkInRepo.findByRegistrationIdIn(
            registrations.stream().map(Registration::getRegistrationId).collect(Collectors.toList())
        );

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        List<Map<String, String>> response = new ArrayList<>();

        for (CheckIn c : checkins) {
            Registration reg = regMap.get(c.getRegistrationId());
            if (reg != null) {
                String userId = reg.getUserId();
                Optional<User> userOpt = userRepo.findById(userId);

                if (userOpt.isPresent()) {
                    User user = userOpt.get();
                    Map<String, String> entry = new HashMap<>();
                    entry.put("student_id", userId.toString());
                    entry.put("name", user.getName());  // ✅ Use actual user name
                    entry.put("sign_in_time", c.getCheckinTime().format(formatter));
                    response.add(entry);
                }
            }
        }

        return ResponseEntity.ok(response);
    }
	
	
}
