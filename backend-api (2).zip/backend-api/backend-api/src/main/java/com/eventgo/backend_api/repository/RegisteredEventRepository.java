package com.eventgo.backend_api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.eventgo.backend_api.model.AvailableEvent;
import com.eventgo.backend_api.model.RegisteredEvent;

public interface RegisteredEventRepository extends JpaRepository<RegisteredEvent, String> {
	@Query(value = "SELECT * FROM view_registered_events WHERE user_id = :userId", nativeQuery = true)
	List<RegisteredEvent> findByUserId(@Param("userId") String userId);

}