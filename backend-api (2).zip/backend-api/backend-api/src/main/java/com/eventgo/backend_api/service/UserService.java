package com.eventgo.backend_api.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.eventgo.backend_api.model.CreateUserRequest;
import com.eventgo.backend_api.model.User;
import com.eventgo.backend_api.repository.UserRepository;
@Service
public class UserService {

 private final UserRepository userRepository;
	 
	 // Constructor injection - make sure the constructor name matches the class name
	 public UserService(UserRepository userRepository) {
	     this.userRepository = userRepository;
	 }

	 public User registerUser(CreateUserRequest request)
	 {
		 User user = new User();
		 user.setUserId(request.getUserId());
		 user.setName(request.getName());
		 user.setEmail(request.getEmail());
		 user.setRole(request.getRole());
		 user.setCreatedAt(LocalDateTime.now());
		return userRepository.save(user);
	 }
	 
	 public User getUserByEmail(String email)
	 {
		 return userRepository.findByEmail(email).orElse(null);
	 }
}
