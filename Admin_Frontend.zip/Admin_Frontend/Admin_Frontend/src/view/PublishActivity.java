//PublishActivity.java
package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.*;

public class PublishActivity {

    private JFrame frame;
    private JTextField titleField, venueField, maxParticipantsField;
    private JTextArea descriptionArea;
    private JComboBox<String> startDateComboBox, startTimeComboBox;
    private JComboBox<String> endDateComboBox, endTimeComboBox;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                PublishActivity window = new PublishActivity();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public PublishActivity() {
        initialize();
        frame.setVisible(true);
    }

    private void initialize() {
        Color lightBlue = Color.decode("#E9F1FA");
        Color brightBlue = Color.decode("#00ABE4");
        Color hoverOrange = Color.decode("#FFA500");
        Color white = Color.WHITE;
        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        Font titleFont = new Font("Segoe UI", Font.BOLD, 36);

        frame = new JFrame("Publish New Activity");
        frame.setBounds(100, 100, 550, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(233, 241, 250));

        JLabel pageTitle = new JLabel("Publish Activity", SwingConstants.CENTER);
        pageTitle.setBounds(100, 10, 350, 40);
        pageTitle.setFont(titleFont);
        pageTitle.setForeground(new Color(0x0077B6));
        frame.getContentPane().add(pageTitle);

        JLabel lblTitle = new JLabel("Title:");
        lblTitle.setBounds(30, 60, 100, 25);
        lblTitle.setFont(labelFont);
        frame.getContentPane().add(lblTitle);

        titleField = new JTextField();
        titleField.setBounds(150, 60, 350, 25);
        titleField.setBackground(white);
        frame.getContentPane().add(titleField);

        JLabel lblDescription = new JLabel("Description:");
        lblDescription.setBounds(30, 100, 100, 25);
        lblDescription.setFont(labelFont);
        frame.getContentPane().add(lblDescription);

        descriptionArea = new JTextArea();
        descriptionArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(descriptionArea);
        scrollPane.setBounds(150, 100, 350, 60);
        descriptionArea.setBackground(white);
        frame.getContentPane().add(scrollPane);

        // --- Start Date & Time ---
        JLabel lblStart = new JLabel("Start:");
        lblStart.setBounds(30, 180, 100, 25);
        lblStart.setFont(labelFont);
        frame.getContentPane().add(lblStart);

        startDateComboBox = new JComboBox<>();
        startTimeComboBox = new JComboBox<>();
        SimpleDateFormat dateFormatOnly = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        for (int i = 0; i < 30; i++) {
            startDateComboBox.addItem(dateFormatOnly.format(calendar.getTime()));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }
        for (int hour = 0; hour < 24; hour++) {
            for (int min = 0; min < 60; min += 30) {
                startTimeComboBox.addItem(String.format("%02d:%02d", hour, min));
            }
        }
        startDateComboBox.setBounds(150, 180, 150, 25);
        startTimeComboBox.setBounds(310, 180, 190, 25);
        frame.getContentPane().add(startDateComboBox);
        frame.getContentPane().add(startTimeComboBox);

        // --- End Date & Time ---
        JLabel lblEnd = new JLabel("End:");
        lblEnd.setBounds(30, 220, 100, 25);
        lblEnd.setFont(labelFont);
        frame.getContentPane().add(lblEnd);

        endDateComboBox = new JComboBox<>();
        endTimeComboBox = new JComboBox<>();
        calendar = Calendar.getInstance(); // reset
        for (int i = 0; i < 30; i++) {
            endDateComboBox.addItem(dateFormatOnly.format(calendar.getTime()));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }
        for (int hour = 0; hour < 24; hour++) {
            for (int min = 0; min < 60; min += 30) {
                endTimeComboBox.addItem(String.format("%02d:%02d", hour, min));
            }
        }
        endDateComboBox.setBounds(150, 220, 150, 25);
        endTimeComboBox.setBounds(310, 220, 190, 25);
        frame.getContentPane().add(endDateComboBox);
        frame.getContentPane().add(endTimeComboBox);

        JLabel lblVenue = new JLabel("Venue:");
        lblVenue.setBounds(30, 260, 100, 25);
        lblVenue.setFont(labelFont);
        frame.getContentPane().add(lblVenue);

        venueField = new JTextField();
        venueField.setBounds(150, 260, 350, 25);
        venueField.setBackground(white);
        frame.getContentPane().add(venueField);

        JLabel lblMax = new JLabel("Max Participants:");
        lblMax.setBounds(30, 300, 130, 25);
        lblMax.setFont(labelFont);
        frame.getContentPane().add(lblMax);

        maxParticipantsField = new JTextField();
        maxParticipantsField.setBounds(180, 300, 100, 25);
        maxParticipantsField.setBackground(white);
        frame.getContentPane().add(maxParticipantsField);

        JButton btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(200, 360, 120, 30);
        btnSubmit.setBackground(brightBlue);
        btnSubmit.setForeground(white);
        btnSubmit.setFocusPainted(false);
        frame.getContentPane().add(btnSubmit);
        btnSubmit.addActionListener(e -> handleSubmit());

        btnSubmit.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnSubmit.setBackground(hoverOrange);
            }

            public void mouseExited(MouseEvent e) {
                btnSubmit.setBackground(brightBlue);
            }
        });

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(30, 420, 100, 30);
        btnBack.setBackground(brightBlue);
        btnBack.setForeground(white);
        btnBack.setFocusPainted(false);
        frame.getContentPane().add(btnBack);
        btnBack.addActionListener(e -> {
            frame.dispose();
            MainMenu.main(null);
        });

        btnBack.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnBack.setBackground(hoverOrange);
            }

            public void mouseExited(MouseEvent e) {
                btnBack.setBackground(brightBlue);
            }
        });
    }

    private void handleSubmit() {
        String title = titleField.getText().trim();
        String description = descriptionArea.getText().trim();
        String venue = venueField.getText().trim();
        String maxParticipantsStr = maxParticipantsField.getText().trim();

        if (title.isEmpty() || description.isEmpty() || venue.isEmpty() || maxParticipantsStr.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill in all fields.");
            return;
        }

        int maxParticipants;
        try {
            maxParticipants = Integer.parseInt(maxParticipantsStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Max Participants must be a number.");
            return;
        }

        String startDateTimeStr = (String) startDateComboBox.getSelectedItem() + " " + (String) startTimeComboBox.getSelectedItem();
        String endDateTimeStr = (String) endDateComboBox.getSelectedItem() + " " + (String) endTimeComboBox.getSelectedItem();

        SimpleDateFormat fullFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date startDateTime, endDateTime;
        try {
            startDateTime = fullFormat.parse(startDateTimeStr);
            endDateTime = fullFormat.parse(endDateTimeStr);

            Date nowPlusOneMinute = new Date(System.currentTimeMillis() + 60000);
            if (!startDateTime.after(nowPlusOneMinute)) {
                JOptionPane.showMessageDialog(frame, "Start time must be at least 1 minute later than now.");
                return;
            }
            if (!endDateTime.after(startDateTime)) {
                JOptionPane.showMessageDialog(frame, "End time must be after Start time.");
                return;
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(frame, "Invalid date/time selected.");
            return;
        }

        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        String formattedStart = isoFormat.format(startDateTime);
        String formattedEnd = isoFormat.format(endDateTime);

        String json = String.format(
            "{" +
                "\"title\":\"%s\"," +
                "\"description\":\"%s\"," +
                "\"startDateTime\":\"%s\"," +
                "\"endDateTime\":\"%s\"," +
                "\"location\":\"%s\"," +
                "\"capacity\":%d," +
                "\"userId\":%d" +
            "}",
            title, description, formattedStart, formattedEnd, venue, maxParticipants, 1
        );

        try {
            String response = ApiClient.sendPost("http://localhost:8080/api/events/publish", json);
            JOptionPane.showMessageDialog(frame, "Activity created successfully!\nResponse: " + response);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to create activity.\n" + ex.getMessage());
        }
    }
}
