//ReviewRegistration.java(frontend)
package view;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import org.json.*;

public class ReviewRegistration {

    private JFrame frame;
    private JTextField eventIdField;
    private JTable table;
    private DefaultTableModel tableModel;
    private String currentEventId;
    private final String[] statusOptions = {"Approved", "Rejected"};

    // Color scheme
    private final Color lightBlue = Color.decode("#E9F1FA");
    private final Color brightBlue = Color.decode("#00ABE4");
    private final Color hoverOrange = Color.decode("#FFA500");

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ReviewRegistration window = new ReviewRegistration();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ReviewRegistration() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Review Registrations");
        frame.setBounds(100, 100, 700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(lightBlue);

        JLabel title = new JLabel(" Review Registrations", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title.setForeground(new Color(0x0077B6));
        title.setBounds(150, 10, 400, 30);
        frame.getContentPane().add(title);

        JLabel lblEventId = new JLabel("Event ID:");
        lblEventId.setBounds(30, 50, 80, 25);
        lblEventId.setFont(new Font("Segoe UI", Font.BOLD, 14));
        frame.getContentPane().add(lblEventId);

        eventIdField = new JTextField();
        eventIdField.setBounds(100, 50, 200, 25);
        eventIdField.setFont(new Font("Segoe UI", Font.BOLD, 14));
        frame.getContentPane().add(eventIdField);

        JButton btnLoad = createStyledButton("Load Registrations", brightBlue, hoverOrange);
        btnLoad.setBounds(320, 50, 180, 25);
        frame.getContentPane().add(btnLoad);
        btnLoad.addActionListener(e -> loadRegistrations());

        tableModel = new DefaultTableModel(new Object[]{"Student ID", "Name", "Status", "New Status", "Action"}, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 3 || column == 4;
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));

        JComboBox<String> comboBox = new JComboBox<>(statusOptions);
        table.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(comboBox));
        table.getColumnModel().getColumn(3).setCellRenderer(new ComboBoxRenderer());

        table.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
        table.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox(), this));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(30, 100, 620, 300);
        frame.getContentPane().add(scrollPane);

        JButton btnBack = createStyledButton("Back", brightBlue, hoverOrange);
        btnBack.setBounds(30, 420, 100, 30);
        frame.getContentPane().add(btnBack);
        btnBack.addActionListener(e -> {
            frame.dispose();
            MainMenu.main(null);
        });

        frame.setVisible(true);
    }

    public void loadRegistrations() {
        String eventId = eventIdField.getText().trim();
        if (eventId.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter an Event ID.");
            return;
        }

        currentEventId = eventId; // ✅ This is the key fix

        String url = "http://localhost:8080/api/registration/byEvent?eventId=" + eventId;

        try {
            String response = ApiClient.sendGet(url);
            JSONArray arr = new JSONArray(response);
            tableModel.setRowCount(0);

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String studentId = obj.getString("student_id");
                String name = obj.getString("name");
                String status = obj.getString("status"); // Possibly rename if this is actually 'status'

                tableModel.addRow(new Object[]{studentId, name, status, status, "Update"});
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to load registration data.");
        }
    }

    public void updateStudentStatus(String studentId, String status) throws Exception {
        String url = "http://localhost:8080/api/registration/update-status";
        String payload = String.format(
            "{\"event_id\":\"%s\", \"student_id\":\"%s\", \"status\":\"%s\"}",
            currentEventId.trim(), studentId.trim(), status.trim()
        );
        System.out.println(studentId+status+currentEventId);
        // Send the HTTP POST request
        String response = ApiClient.sendPost(url, payload);
        System.out.println("Server response: " + response);
    }


    private JButton createStyledButton(String text, Color baseColor, Color hoverColor) {
        JButton button = new JButton(text);
        button.setBackground(baseColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(hoverColor);
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(baseColor);
            }
        });

        return button;
    }

    class ComboBoxRenderer extends JComboBox<String> implements TableCellRenderer {
        public ComboBoxRenderer() {
            super(statusOptions);
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            setSelectedItem(value);
            return this;
        }
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setText("Update");
            setBackground(brightBlue);
            setForeground(Color.WHITE);
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String studentId;
        private String newStatus;
        private ReviewRegistration parent;

        public ButtonEditor(JCheckBox checkBox, ReviewRegistration parent) {
            super(checkBox);
            this.parent = parent;

            button = createStyledButton("Update", brightBlue, hoverOrange);

            button.addActionListener(e -> {
                try {
                    parent.updateStudentStatus(studentId, newStatus);
                    JOptionPane.showMessageDialog(frame, "Status updated for " + studentId);
                    parent.loadRegistrations();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Failed to update status.");
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            studentId = (String) table.getValueAt(row, 0);
            newStatus = (String) table.getValueAt(row, 3);
            return button;
        }
    }
}
