package view;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class QRCodeViewer {

    private JFrame frame;
    private JTextField eventIdField;
    private JLabel imageLabel;
    private BufferedImage qrImage;

    // Colors and Fonts
    private final Color lightBlue = Color.decode("#E9F1FA");
    private final Color brightBlue = Color.decode("#00ABE4");
    private final Color textBlue = Color.decode("#0077B6");
    private final Color hoverOrange = Color.decode("#FFA500");
    private final Color white = Color.WHITE;

    private final Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font titleFont = new Font("Segoe UI", Font.BOLD, 20);
    private final Font buttonFont = new Font("Segoe UI", Font.BOLD, 14);

    public QRCodeViewer() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("QR Code Viewer");
        frame.setBounds(100, 100, 550, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(lightBlue);

        // Title
        JLabel title = new JLabel(" QR Code Viewer", SwingConstants.CENTER);
        title.setFont(titleFont);
        title.setForeground(textBlue);
        title.setBounds(100, 10, 350, 30);
        frame.getContentPane().add(title);

        // Event ID Label
        JLabel lblEventId = new JLabel("Event ID:");
        lblEventId.setFont(labelFont);
        lblEventId.setBounds(50, 60, 100, 25);
        frame.getContentPane().add(lblEventId);

        // Event ID TextField
        eventIdField = new JTextField();
        eventIdField.setBounds(140, 60, 250, 25);
        eventIdField.setBackground(white);
        frame.getContentPane().add(eventIdField);

        // Get QR Code Button
        JButton fetchButton = new JButton("Get QR Code");
        fetchButton.setBounds(140, 100, 150, 30);
        fetchButton.setBackground(brightBlue);
        fetchButton.setForeground(white);
        fetchButton.setFont(buttonFont);
        fetchButton.setFocusPainted(false);
        fetchButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        frame.getContentPane().add(fetchButton);

        fetchButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent evt) {
                fetchButton.setBackground(hoverOrange);
            }

            @Override
            public void mouseExited(MouseEvent evt) {
                fetchButton.setBackground(brightBlue);
            }
        });

        // QR Code display
        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setBounds(125, 160, 300, 250);
        imageLabel.setOpaque(true);
        imageLabel.setBackground(white);
        frame.getContentPane().add(imageLabel);

        // Download Button
        JButton downloadButton = new JButton("Download QR");
        downloadButton.setBounds(200, 430, 140, 30);
        downloadButton.setBackground(brightBlue);
        downloadButton.setForeground(white);
        downloadButton.setFont(buttonFont);
        downloadButton.setFocusPainted(false);
        downloadButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        frame.getContentPane().add(downloadButton);

        downloadButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent evt) {
                downloadButton.setBackground(hoverOrange);
            }

            @Override
            public void mouseExited(MouseEvent evt) {
                downloadButton.setBackground(brightBlue);
            }
        });

        // Back Button
        JButton btnBack = new JButton("Back");
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBackground(brightBlue);
        btnBack.setBounds(31, 452, 100, 30);
        frame.getContentPane().add(btnBack);

        btnBack.addActionListener(e -> {
            frame.dispose();
            MainMenu.main(null);
        });

        btnBack.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnBack.setBackground(hoverOrange);
            }

            public void mouseExited(MouseEvent e) {
                btnBack.setBackground(brightBlue);
            }
        });

        // Action listeners
        fetchButton.addActionListener(e -> fetchQRCode());
        downloadButton.addActionListener(e -> downloadQRCode());

        frame.setVisible(true);
    }

    private void fetchQRCode() {
        String eventId = eventIdField.getText().trim();
        if (eventId.isEmpty() || !eventId.matches("\\d+")) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid numeric event ID.");
            return;
        }

        try {
            String urlStr = "http://localhost:8080/api/events/QRCode?eventId=" + eventId;
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int responseCode = conn.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                qrImage = ImageIO.read(conn.getInputStream());
                if (qrImage != null) {
                    ImageIcon icon = new ImageIcon(qrImage.getScaledInstance(250, 250, Image.SCALE_SMOOTH));
                    imageLabel.setIcon(icon);
                } else {
                    JOptionPane.showMessageDialog(frame, "Failed to load QR code image.");
                }
            } else {
                InputStream errorStream = conn.getErrorStream();
                StringBuilder errorMessage = new StringBuilder("Unknown error");
                if (errorStream != null) {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(errorStream))) {
                        String line;
                        errorMessage.setLength(0); // Clear default
                        while ((line = reader.readLine()) != null) {
                            errorMessage.append(line).append("\n");
                        }
                    }
                }

                JOptionPane.showMessageDialog(frame, errorMessage.toString().trim());
            }

            conn.disconnect();

        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
        }
    }


    private void downloadQRCode() {
        if (qrImage == null) {
            JOptionPane.showMessageDialog(frame, "No QR code to download. Fetch one first.");
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setSelectedFile(new File("event-qr.png"));
        int result = fileChooser.showSaveDialog(frame);

        if (result == JFileChooser.APPROVE_OPTION) {
            try {
                File file = fileChooser.getSelectedFile();
                ImageIO.write(qrImage, "png", file);
                JOptionPane.showMessageDialog(frame, "QR code saved to: " + file.getAbsolutePath());
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Failed to save QR code.");
            }
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new QRCodeViewer());
    }
}
