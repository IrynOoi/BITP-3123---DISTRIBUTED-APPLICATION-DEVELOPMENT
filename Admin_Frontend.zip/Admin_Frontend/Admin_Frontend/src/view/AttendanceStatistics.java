package view;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import org.json.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;

public class AttendanceStatistics {

    private JFrame frame;
    private JComboBox<String> eventComboBox;
    private JLabel lblRegistered, lblSignedIn, lblPercentage;
    private JPanel chartPanel;
    private Map<String, String> eventMap = new HashMap<>();

    private static final String BACKEND_BASE_URL = "http://localhost:8080";

    // 统一颜色样式
    private final Color lightBlue = Color.decode("#E9F1FA");
    private final Color brightBlue = Color.decode("#00ABE4");
    private final Color hoverOrange = Color.decode("#FFA500");
    private final Color textBlue = Color.decode("#0077B6");
    private final Color white = Color.WHITE;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                AttendanceStatistics window = new AttendanceStatistics();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public AttendanceStatistics() {
        initialize();
        frame.setVisible(true);
        loadEventList();
    }

    private void initialize() {
        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        Font titleFont = new Font("Segoe UI", Font.BOLD, 28);
        Font buttonFont = new Font("Segoe UI", Font.BOLD, 14);

        frame = new JFrame("Attendance Statistics");
        frame.setBounds(100, 100, 750, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(lightBlue);

        JLabel title = new JLabel(" Attendance Statistics", SwingConstants.CENTER);
        title.setFont(titleFont);
        title.setForeground(textBlue);
        title.setBounds(150, 10, 450, 40);
        frame.getContentPane().add(title);

        JLabel lblSelectEvent = new JLabel("Select Event:");
        lblSelectEvent.setFont(labelFont);
        lblSelectEvent.setBounds(30, 60, 100, 25);
        frame.getContentPane().add(lblSelectEvent);

        eventComboBox = new JComboBox<>();
        eventComboBox.setFont(labelFont);
        eventComboBox.setBounds(130, 60, 300, 25);
        frame.getContentPane().add(eventComboBox);

        JButton btnLoadStats = createStyledButton("Load Statistics");
        btnLoadStats.setFont(buttonFont);
        btnLoadStats.setBounds(450, 60, 150, 30);
        frame.getContentPane().add(btnLoadStats);

        lblRegistered = new JLabel("Registered: ");
        lblRegistered.setFont(labelFont);
        lblRegistered.setBounds(30, 110, 300, 25);
        frame.getContentPane().add(lblRegistered);

        lblSignedIn = new JLabel("Signed-In: ");
        lblSignedIn.setFont(labelFont);
        lblSignedIn.setBounds(30, 140, 300, 25);
        frame.getContentPane().add(lblSignedIn);

        lblPercentage = new JLabel("Attendance: ");
        lblPercentage.setFont(labelFont);
        lblPercentage.setBounds(30, 170, 300, 25);
        frame.getContentPane().add(lblPercentage);

        chartPanel = new JPanel();
        chartPanel.setBounds(300, 120, 400, 350);
        chartPanel.setBackground(white);
        frame.getContentPane().add(chartPanel);

        JButton btnBack = createStyledButton("Back");
        btnBack.setFont(buttonFont);
        btnBack.setBounds(30, 460, 100, 30);
        frame.getContentPane().add(btnBack);

        btnLoadStats.addActionListener(e -> loadAttendanceStats());
        btnBack.addActionListener(e -> {
            frame.dispose();
            MainMenu.main(null);
        });
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(brightBlue);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(hoverOrange);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(brightBlue);
            }
        });

        return button;
    }

    private void loadEventList() {
        String url = BACKEND_BASE_URL + "/api/events";

        try {
            String response = ApiClient.sendGet(url);
            JSONArray arr = new JSONArray(response);
            eventComboBox.removeAllItems();

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String id = String.valueOf(obj.getInt("eventId"));
                String name = obj.getString("title");
                eventMap.put(name, id);
                eventComboBox.addItem(name);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to load event list.");
        }
    }

    private void loadAttendanceStats() {
        String selectedEvent = (String) eventComboBox.getSelectedItem();
        if (selectedEvent == null) return;

        String eventId = eventMap.get(selectedEvent);
        String url = BACKEND_BASE_URL + "/api/events/attendanceStats?event_id=" + eventId;


        try {
            String response = ApiClient.sendGet(url);
            JSONObject obj = new JSONObject(response);

            int registered = obj.getInt("totalRegistrations");
            int signedIn = obj.getInt("attended");
            double percentage = registered == 0 ? 0 : (signedIn * 100.0 / registered);

            lblRegistered.setText("Registered: " + registered);
            lblSignedIn.setText("Signed-In: " + signedIn);
            lblPercentage.setText("Attendance: " + String.format("%.2f", percentage) + "%");

            DefaultPieDataset dataset = new DefaultPieDataset();
            dataset.setValue("Signed In", signedIn);
            dataset.setValue("Not Signed In", Math.max(0, registered - signedIn));

            JFreeChart pieChart = ChartFactory.createPieChart(
                    "Attendance Chart", dataset, true, true, false);

            PiePlot plot = (PiePlot) pieChart.getPlot();
            plot.setSectionPaint("Signed In", new Color(76, 175, 80)); // Green
            plot.setSectionPaint("Not Signed In", new Color(244, 67, 54)); // Red
            plot.setLabelFont(new Font("Segoe UI", Font.PLAIN, 12));
            plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {1} ({2})"));

            ChartPanel chart = new ChartPanel(pieChart);
            chart.setPreferredSize(new Dimension(380, 300));

            chartPanel.removeAll();
            chartPanel.add(chart);
            chartPanel.revalidate();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to load attendance data.");
        }
    }
}