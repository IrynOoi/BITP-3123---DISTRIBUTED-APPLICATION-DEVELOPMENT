//SigninData.java(front end )
package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.io.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class SignInData {

    private JFrame frame;
    private JTextField eventIdField;
    private JTable table;
    private DefaultTableModel tableModel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                SignInData window = new SignInData();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public SignInData() {
        initialize();
        frame.setVisible(true);
    }

    private void initialize() {
        // Colors & Fonts
        Color lightBlue = Color.decode("#E9F1FA");
        Color brightBlue = Color.decode("#00ABE4");
        Color hoverOrange = Color.decode("#FFA500");
        Color white = Color.WHITE;
        Color textBlue = Color.decode("#0077B6");

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font buttonFont = new Font("Segoe UI", Font.BOLD, 14);
        Font tableFont = new Font("Segoe UI", Font.PLAIN, 13);
        Font tableHeaderFont = new Font("Segoe UI", Font.BOLD, 14);
        Font titleFont = new Font("Segoe UI", Font.BOLD, 28);

        frame = new JFrame("Sign-In Data Management");
        frame.setBounds(100, 100, 650, 520);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(lightBlue);

        // Title
        JLabel lblTitle = new JLabel("View Sign-In Data", SwingConstants.CENTER);
        lblTitle.setBounds(100, 10, 450, 40);
        lblTitle.setFont(titleFont);
        lblTitle.setForeground(textBlue);
        frame.getContentPane().add(lblTitle);

        // Event ID input
        JLabel lblEventId = new JLabel("Event ID:");
        lblEventId.setBounds(30, 70, 80, 25);
        lblEventId.setFont(labelFont);
        lblEventId.setForeground(textBlue);
        frame.getContentPane().add(lblEventId);

        eventIdField = new JTextField();
        eventIdField.setBounds(100, 70, 200, 25);
        frame.getContentPane().add(eventIdField);

        // Refresh Button
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.setBounds(320, 70, 100, 25);
        btnRefresh.setBackground(brightBlue);
        btnRefresh.setForeground(white);
        btnRefresh.setFont(buttonFont);
        btnRefresh.setFocusPainted(false);
        frame.getContentPane().add(btnRefresh);

        btnRefresh.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnRefresh.setBackground(hoverOrange);
            }

            public void mouseExited(MouseEvent e) {
                btnRefresh.setBackground(brightBlue);
            }
        });

        // Export Button
        JButton btnExport = new JButton("Export CSV");
        btnExport.setBounds(430, 70, 120, 25);
        btnExport.setBackground(brightBlue);
        btnExport.setForeground(white);
        btnExport.setFont(buttonFont);
        btnExport.setFocusPainted(false);
        frame.getContentPane().add(btnExport);

        btnExport.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnExport.setBackground(hoverOrange);
            }

            public void mouseExited(MouseEvent e) {
                btnExport.setBackground(brightBlue);
            }
        });

        // Table
        tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new String[]{"Student ID", "Name", "Sign-In Time"});

        table = new JTable(tableModel);
        table.setFont(tableFont);
        table.setRowHeight(24);

        JTableHeader header = table.getTableHeader();
        header.setFont(tableHeaderFont);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(30, 120, 570, 300);
        frame.getContentPane().add(scrollPane);

        // Back Button
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(30, 430, 100, 30);
        btnBack.setBackground(brightBlue);
        btnBack.setForeground(white);
        btnBack.setFont(buttonFont);
        btnBack.setFocusPainted(false);
        frame.getContentPane().add(btnBack);

        btnBack.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnBack.setBackground(hoverOrange);
            }

            public void mouseExited(MouseEvent e) {
                btnBack.setBackground(brightBlue);
            }
        });

        // Action Listeners
        btnBack.addActionListener(e -> {
            frame.dispose();
            MainMenu.main(null);
        });

        btnRefresh.addActionListener(e -> fetchSignInData());
        btnExport.addActionListener(e -> exportToCSV());
    }

    private void fetchSignInData() {
        String eventId = eventIdField.getText().trim();
        if (eventId.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter an Event ID.");
            return;
        }

        String url = "http://localhost:8080/api/checkin/signIn?event_id=" + eventId;

        try {
            String response = ApiClient.sendGet(url);
            JSONArray jsonArr = new JSONArray(response);

            tableModel.setRowCount(0); // Clear table
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject obj = jsonArr.getJSONObject(i);
                String sid = obj.getString("student_id");
                String name = obj.getString("name");
                String time = obj.getString("sign_in_time");
                tableModel.addRow(new Object[]{sid, name, time});
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to load data.\n" + e.getMessage());
        }
    }

    private void exportToCSV() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save CSV File");

        int userSelection = fileChooser.showSaveDialog(frame);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    writer.write(tableModel.getColumnName(i) + (i < tableModel.getColumnCount() - 1 ? "," : ""));
                }
                writer.newLine();

                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        writer.write(tableModel.getValueAt(row, col).toString() + (col < tableModel.getColumnCount() - 1 ? "," : ""));
                    }
                    writer.newLine();
                }

                JOptionPane.showMessageDialog(frame, "CSV file saved successfully!");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Failed to save CSV.\n" + e.getMessage());
            }
        }
    }
}
