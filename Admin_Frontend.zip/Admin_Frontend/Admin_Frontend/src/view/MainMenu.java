package view;

import javax.swing.*;


import java.awt.*;


public class MainMenu {

    private JFrame frame;

    public MainMenu() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Main Menu");
        frame.setSize(400, 450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.decode("#E9F1FA"));

        JLabel titleLabel = new JLabel("EventGo - Admin Dashboard", SwingConstants.CENTER);
        titleLabel.setBounds(50, 20, 300, 30);
        titleLabel.setForeground(Color.decode("#00ABE4"));
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        frame.add(titleLabel);

        Font btnFont = new Font("Segoe UI", Font.BOLD, 14);

        JButton btnPublish = createStyledButton("Publish Activity", 70, btnFont);
        JButton btnQRCode = createStyledButton("Display QR Code", 110, btnFont);
        JButton btnReview = createStyledButton("Review Registrations", 150, btnFont);
        JButton btnSignInData = createStyledButton("View Sign-In Data", 190, btnFont);
        JButton btnStatistics = createStyledButton("Attendance Statistics", 230, btnFont);

        frame.add(btnPublish);
        frame.add(btnQRCode);
        frame.add(btnReview);
        frame.add(btnSignInData);
        frame.add(btnStatistics);

        btnPublish.addActionListener(e -> {
            frame.dispose();
            new PublishActivity();
        });

        btnQRCode.addActionListener(e -> {
            frame.dispose();
            new QRCodeViewer();
        });

        btnReview.addActionListener(e -> {
            frame.dispose();
            new ReviewRegistration(); // 这里是你原来打开的
        });

        btnSignInData.addActionListener(e -> {
            frame.dispose();
            new SignInData();
        });

        btnStatistics.addActionListener(e -> {
            frame.dispose();
            new AttendanceStatistics();
        });

        frame.setVisible(true); // 关键点：设置可见
    }

    private JButton createStyledButton(String text, int y, Font font) {
        JButton button = new JButton(text);
        button.setBounds(100, y, 200, 35);
        button.setFont(font);
        button.setBackground(Color.decode("#00ABE4"));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenu());
    }
}
